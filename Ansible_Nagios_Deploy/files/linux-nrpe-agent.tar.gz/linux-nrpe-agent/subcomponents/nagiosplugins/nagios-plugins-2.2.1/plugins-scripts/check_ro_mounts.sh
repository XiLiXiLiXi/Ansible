#!/bin/sh

source /home/nagios/.bash_profile
cd /home/nagios/libexec
perl check_ro_mounts

